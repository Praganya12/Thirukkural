// PascalCasing
function Message() {
  // JSX: Javascript XML
  const name = "";
  if (name) return <h1>Hello {name}</h1>;
  return <h2>Hello world</h2>;
}
export default Message;
